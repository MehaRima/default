# AndoidDeveloperApplications
Apps built from my Udemy course, The Complete Android Oreo Developer Course - By Rob Percival and Nick Walter

# Completed

- ### Higher or Lower App

An app that uses a random number generator to generate a random number for the user to guess. The goal of the app is to have the user guess the random number. The random number is currently set to be between 1 and 20. After the user types a guess and clicks the button guesss button, a toast will inform them whether their guess was too high, too low, or correct. If their guess is correct, a new random number is automatically geerated and they can begin guessing again.

- ### Number Shapes App

An app which allows the user to enter any number. Using classes, loops and algorithms this app identifies whether the number entered by the user is a triangular number, a square number, both, or neither. The user is informed with a toast.

- ### Connect 3 Game

An app that allows two users to play tic tac toes. The users will be playing on a 3x3 board where they have to tap the location on the screen that they want to place there piece. The first person to get a line of 3 wins.
